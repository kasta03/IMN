for file in plots/*.txt; do
  new_name=$(echo "$file" | sed -E 's/([0-9]+\.[0-9])[0-9]*/\1/')
  
  if [[ "$file" != "$new_name" ]]; then
    mv "$file" "$new_name"
  fi
done
