#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <filesystem>
#include <iomanip>

const int NX = 400;
const int NY = 90;
const int I1 = 200;
const int I2 = 210;
const int J1 = 50;
const double DELTA = 0.01;
const double SIGMA = 10.0 * DELTA;
const double XA = 0.45;
const double YA = 0.45;
const int IT_MAX = 10000;

double x(int i) {
    return DELTA * i;
}

double y(int j) {
    return DELTA * j;
}

double initial_u(double xi, double yj) {
    return std::exp(-((xi - XA) * (xi - XA) + (yj - YA) * (yj - YA)) / (2.0 * SIGMA * SIGMA)) / 
           (2.0 * M_PI * SIGMA * SIGMA);
}

void compute_velocity_field(const std::vector<std::vector<double>>& psi_v_f, 
                          std::vector<std::vector<double>>& vx_v_f, 
                          std::vector<std::vector<double>>& vy_v_f) {
    for (int i = 1; i < NX; i++) {
        for (int j = 1; j < NY; j++) {
            vx_v_f[i][j] = (psi_v_f[i][j + 1] - psi_v_f[i][j - 1]) / (2.0 * DELTA);
            vy_v_f[i][j] = -(psi_v_f[i + 1][j] - psi_v_f[i - 1][j]) / (2.0 * DELTA);
        }
    }

    for (int i = I1; i <= I2; i++) {
        for (int j = 0; j <= J1; j++) {
            vx_v_f[i][j] = 0.0;
            vy_v_f[i][j] = 0.0;
        }
    }

    for (int i = 1; i < NX; i++) {
        vx_v_f[i][0] = 0.0;
        vy_v_f[i][NY] = 0.0;
    }

    for (int j = 0; j <= NY; j++) {
        vx_v_f[0][j] = vx_v_f[1][j];
        vx_v_f[NX][j] = vx_v_f[NX - 1][j];
    }
}

double find_vmax(const std::vector<std::vector<double>>& vx_f_m, 
                const std::vector<std::vector<double>>& vy_f_m) {
    double v_f_max = 0.0;
    for (int i = 0; i <= NX; i++) {
        for (int j = 0; j <= NY; j++) {
            double v_mag = std::sqrt(vx_f_m[i][j] * vx_f_m[i][j] + 
                                   vy_f_m[i][j] * vy_f_m[i][j]);
            if (v_mag > v_f_max) {
                v_f_max = v_mag;
            }
        }
    }
    return v_f_max;
}

void crank_nicolson_step(const std::vector<std::vector<double>>& u0_n_s,
                        std::vector<std::vector<double>>& u1_n_s,
                        const std::vector<std::vector<double>>& vx_n_s,
                        const std::vector<std::vector<double>>& vy_n_s,
                        double d, double dt_n_s) {
    for (int k_n_s = 0; k_n_s < 20; k_n_s++) {
        for (int i = 0; i <= NX; i++) {
            for (int j = 1; j < NY; j++) {
                // Zastawka
                if (i >= I1 && i <= I2 && j <= J1) {
                    continue;
                }

                int i_left = i - 1;
                int i_right = i + 1;
                if (i == 0) {
                    i_left = NX;
                }
                if (i == NX) {
                    i_right = 0;
                }

                double u0_ij = u0_n_s[i][j];

                // Adwekcja w x
                double dudx0 = (u0_n_s[i_right][j] - u0_n_s[i_left][j]) / (2.0 * DELTA);
                double dudx1 = (u1_n_s[i_right][j] - u1_n_s[i_left][j]) / (2.0 * DELTA);
                // Adwekcja w y
                double dudy0 = (u0_n_s[i][j + 1] - u0_n_s[i][j - 1]) / (2.0 * DELTA);
                double dudy1 = (u1_n_s[i][j + 1] - u1_n_s[i][j - 1]) / (2.0 * DELTA);

                // Dyfuzja
                double lapl0 = (u0_n_s[i_right][j] + u0_n_s[i_left][j] + 
                              u0_n_s[i][j + 1] + u0_n_s[i][j - 1] - 
                              4.0 * u0_ij) / (DELTA * DELTA);
                double lapl1 = (u1_n_s[i_right][j] + u1_n_s[i_left][j] + 
                              u1_n_s[i][j + 1] + u1_n_s[i][j - 1]) / 
                              (DELTA * DELTA);

                double numer = (u0_ij - dt_n_s * (vx_n_s[i][j] / 2.0) * (dudx0 + dudx1) -
                              dt_n_s * (vy_n_s[i][j] / 2.0) * (dudy0 + dudy1) + 
                              (dt_n_s * d / 2.0) * (lapl0 + lapl1));

                double denom = 1.0 + (2.0 * d * dt_n_s) / (DELTA * DELTA);

                u1_n_s[i][j] = numer / denom;
            }
        }
    }
}

void save_matrix_to_file(const std::string& filename, 
                        const std::vector<std::vector<double>>& matrix) {
    std::ofstream file(filename);
    file << std::scientific << std::setprecision(16);
    
    for (int i = 0; i <= NX; i++) {
        for (int j = 0; j <= NY; j++) {
            file << matrix[i][j];
            if (j < NY) {
                file << " ";
            }
        }
        file << "\n";
    }
}

void save_vector_to_file(const std::string& filename, 
                        const std::vector<double>& vec) {
    std::ofstream file(filename);
    file << std::scientific << std::setprecision(16);
    for (const auto& val : vec) {
        file << val << "\n";
    }
}

int main() {
    std::filesystem::create_directory("plots");

    // Tworzenie siatek
    std::vector<double> grid_x(NX + 1);
    std::vector<double> grid_y(NY + 1);
    for (int i = 0; i <= NX; i++) grid_x[i] = x(i);
    for (int j = 0; j <= NY; j++) grid_y[j] = y(j);

    save_vector_to_file("plots/grid_x.txt", grid_x);
    save_vector_to_file("plots/grid_y.txt", grid_y);

    // Inicjalizacja psi z pliku
    std::vector<std::vector<double>> psi(NX + 1, std::vector<double>(NY + 1, 0.0));
    std::ifstream psi_file("psi.dat");
    int i_, j_;
    double val;
    while (psi_file >> i_ >> j_ >> val) {
        psi[i_][j_] = val;
    }

    // Inicjalizacja pól prędkości
    std::vector<std::vector<double>> vx(NX + 1, std::vector<double>(NY + 1, 0.0));
    std::vector<std::vector<double>> vy(NX + 1, std::vector<double>(NY + 1, 0.0));
    compute_velocity_field(psi, vx, vy);

    save_matrix_to_file("plots/vx.txt", vx);
    save_matrix_to_file("plots/vy.txt", vy);

    double v_max = find_vmax(vx, vy);
    double dt = DELTA / (4.0 * v_max);
    std::cout << "Vmax = " << v_max << ", dt = " << dt << std::endl;

    std::vector<double> grid_t(IT_MAX);
    for (int it = 0; it < IT_MAX; it++) grid_t[it] = dt * it;
    save_vector_to_file("plots/grid_t.txt", grid_t);

    std::vector<std::vector<double>> u0(NX + 1, std::vector<double>(NY + 1, 0.0));
    std::vector<std::vector<double>> u1(NX + 1, std::vector<double>(NY + 1, 0.0));

    std::vector<double> D_values = {0.0, 0.1};
    for (double D : D_values) {
        std::cout << "\nCalculating for D = " << D << std::endl;
        std::ofstream c_file("plots/c_" + std::to_string(D) + ".txt");
        std::ofstream x_sr_file("plots/x_sr_" + std::to_string(D) + ".txt");
        c_file << std::scientific << std::setprecision(16);
        x_sr_file << std::scientific << std::setprecision(16);

        // Inicjalizacja warunku początkowego
        for (int i = 0; i <= NX; i++) {
            for (int j = 0; j <= NY; j++) {
                u0[i][j] = initial_u(grid_x[i], grid_y[j]);
            }
        }

        for (int it = 1; it <= IT_MAX; it++) {
            // Kopiowanie u0 do u1
            for (int i = 0; i <= NX; i++) {
                for (int j = 0; j <= NY; j++) {
                    u1[i][j] = u0[i][j];
                }
            }

            crank_nicolson_step(u0, u1, vx, vy, D, dt);

            // Kopiowanie u1 z powrotem do u0
            for (int i = 0; i <= NX; i++) {
                for (int j = 0; j <= NY; j++) {
                    u0[i][j] = u1[i][j];
                }
            }

            double c_val = 0.0;
            double x_sr_val = 0.0;
            for (int i = 0; i <= NX; i++) {
                for (int j = 0; j <= NY; j++) {
                    c_val += u0[i][j] * DELTA * DELTA;
                    x_sr_val += grid_x[i] * u0[i][j] * DELTA * DELTA;
                }
            }

            c_file << c_val << "\n";
            x_sr_file << x_sr_val << "\n";

            double t_curr = it * dt;
            double tmax = IT_MAX * dt;
            for (int k = 1; k <= 5; k++) {
                if (std::abs(t_curr - k * (tmax / 5.0)) < 1e-14) {
                    std::string filename = "plots/u_" + std::to_string(D) + "_" + 
                                         std::to_string(k) + ".txt";
                    save_matrix_to_file(filename, u0);
                }
            }
        }
    }

    std::cout << "Done." << std::endl;
    return 0;
}