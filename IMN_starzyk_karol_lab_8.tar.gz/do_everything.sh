#!/bin/bash

# Kompilacja z flagą -O3
echo "Kompilacja z flagą -O3..."
g++ -O3 solution.cpp -o solution

echo "Liczenie..."
./solution

echo "Wykonanie rename"
chmod +x rename.sh
./rename.sh

echo "Wykonanie programu plots.py..."
python3 plots.py

echo "Wejście do folderu i otwarcie plików PNG"
cd plots
code *.png
