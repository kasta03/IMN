#include <iostream>
#include <fstream>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_blas.h>
#include <cmath>

using namespace std;

// Function to calculate the index based on i and j
int getIndex(int i, int j, int nx) {
  return i + j * (nx + 1);
}

// Function to extract i and j from the index
pair<int, int> getIndices(int l, int nx) {
  int j = floor(static_cast<double>(l) / (nx + 1));
  int i = l - j * (nx + 1);
  return make_pair(i, j);
}

void initializeMatrices(gsl_matrix *A, gsl_matrix *B, gsl_vector *c, int nx, int ny, double delta_t, double delta, double TB, double TD) {

    int N = (nx + 1) * (ny + 1);

    double al_val = delta_t / (2 * delta * delta);
    double bl_val = -delta_t / (2 * delta * delta);


     for (int l = 0; l < N; ++l) {
        pair<int, int> indices = getIndices(l, nx);
        int i = indices.first;
        int j = indices.second;

        // Interior points
         if (i > 0 && i < nx && j > 0 && j < ny) {
          gsl_matrix_set(A, l, l - (nx + 1), al_val);
          gsl_matrix_set(A, l, l - 1, al_val);
          gsl_matrix_set(A, l, l, -2 * delta_t / (delta * delta) - 1);
          gsl_matrix_set(A, l, l + 1, al_val);
          gsl_matrix_set(A, l, l + (nx + 1), al_val);

          gsl_matrix_set(B, l, l - (nx + 1), bl_val);
          gsl_matrix_set(B, l, l - 1, bl_val);
          gsl_matrix_set(B, l, l, 2 * delta_t / (delta * delta) - 1);
          gsl_matrix_set(B, l, l + 1, bl_val);
          gsl_matrix_set(B, l, l + (nx + 1), bl_val);
        } 
         //Dirichlet Boundary
         else if (i == 0 || i == nx) {
          gsl_matrix_set(A, l, l, 1.0);
          gsl_matrix_set(B, l, l, 1.0);
           gsl_vector_set(c, l, 0.0);
        }
         // Neumann Boundary (top)
        else if (j == ny && i > 0 && i < nx) {
           double kB = 0.1;
            gsl_matrix_set(A, l, l - (nx + 1), -1.0 / (kB * delta));
            gsl_matrix_set(A, l, l, 1.0 + 1.0 / (kB * delta));
            gsl_vector_set(c, l, TB);
          } 
        //Neumann Boundary (bottom)
        else if (j == 0 && i > 0 && i < nx) {
           double kD = 0.6;
            gsl_matrix_set(A, l, l, 1.0 + 1.0 / (kD * delta));
             gsl_matrix_set(A, l, l + (nx + 1), -1.0 / (kD * delta));
           gsl_vector_set(c, l, TD);
         }
    }
}

void setInitialConditions(gsl_vector *T, int nx, int ny, double TA, double TC) {
   int N = (nx + 1) * (ny + 1);

  for (int l = 0; l < N; ++l) {
    pair<int, int> indices = getIndices(l, nx);
    int i = indices.first;
    int j = indices.second;

    if (i == 0) {
        gsl_vector_set(T, l, TA);
    }
    else if(i == nx){
        gsl_vector_set(T, l, TC);
    }
    else {
      gsl_vector_set(T, l, 0.0);
    }
  }
}

void solveSystem(gsl_matrix *A, gsl_matrix *B, gsl_vector *c, gsl_vector *T, gsl_permutation *p, int nx, int ny, int it) {

  int N = (nx + 1) * (ny + 1);

    gsl_vector *d = gsl_vector_alloc(N);
    gsl_blas_dgemv(CblasNoTrans, 1.0, B, T, 0.0, d); // d = B * T
    gsl_blas_daxpy(1.0, c, d); //d = d + c
    gsl_linalg_LU_solve(A, p, d, T); // Solve A * T = d;
    gsl_vector_free(d);
}


void writeResultsToFile(const gsl_vector *T, int nx, int ny, int it, const string& filePrefix) {
    
     int N = (nx + 1) * (ny + 1);

    string tempFileName = filePrefix + "_temp_" + to_string(it) + ".dat";
    string laplacianFileName = filePrefix + "_laplacian_" + to_string(it) + ".dat";
    
    ofstream tempFile(tempFileName);
    ofstream laplacianFile(laplacianFileName);

    for (int i = 0; i <= nx; ++i) {
        for (int j = 0; j <= ny; ++j) {
             int index = getIndex(i, j, nx);
              double temp_ij = gsl_vector_get(T, index);
              double laplacian_ij = 0.0; // initialize the laplacian to 0
                if (i > 0 && i < nx && j > 0 && j < ny) { // calculate laplacian only if not boundary
                  laplacian_ij = (
                      gsl_vector_get(T, getIndex(i+1,j,nx)) +
                      gsl_vector_get(T, getIndex(i-1,j,nx)) +
                      gsl_vector_get(T, getIndex(i,j+1,nx)) +
                      gsl_vector_get(T, getIndex(i,j-1,nx)) -
                      4.0 * gsl_vector_get(T, index)
                  );
                }

            tempFile << i << " " << j << " " << temp_ij << endl;
            laplacianFile << i << " " << j << " " << laplacian_ij << endl;
        }
    }
    tempFile.close();
    laplacianFile.close();
}


int main() {
    // Parameters
    int nx = 40;
    int ny = 40;
    int N = (nx + 1) * (ny + 1);
    double delta = 1.0;
    double delta_t = 1.0;
    double TA = 40.0;
    double TB = 0.0;
    double TC = 30.0;
    double TD = 0.0;
    int IT_MAX = 2000;


    // Create matrices and vectors
    gsl_matrix *A = gsl_matrix_alloc(N, N);
    gsl_matrix *B = gsl_matrix_alloc(N, N);
    gsl_vector *c = gsl_vector_alloc(N);
    gsl_vector *T = gsl_vector_alloc(N);
    gsl_permutation *p = gsl_permutation_alloc(N);


    // Initialize matrices and vectors
    initializeMatrices(A, B, c, nx, ny, delta_t, delta, TB, TD);
    setInitialConditions(T, nx, ny, TA, TC);


     // LU decomposition of A
    int signum;
    gsl_linalg_LU_decomp(A, p, &signum);

    // Crank-Nicolson algorithm
    for (int it = 0; it <= IT_MAX; ++it) {
        solveSystem(A, B, c, T, p, nx, ny, it);
          if (it == 100 || it == 200 || it == 500 || it == 1000 || it == 2000) {
          writeResultsToFile(T, nx, ny, it, "data");
        }
    }

    // Free memory
    gsl_matrix_free(A);
    gsl_matrix_free(B);
    gsl_vector_free(c);
    gsl_vector_free(T);
    gsl_permutation_free(p);

    return 0;
}