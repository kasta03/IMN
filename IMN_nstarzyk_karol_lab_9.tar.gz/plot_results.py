import matplotlib.pyplot as plt
import numpy as np
import os

def plot_and_save_data(file_prefix, it):
  temp_filename = f"{file_prefix}_temp_{it}.dat"
  laplacian_filename = f"{file_prefix}_laplacian_{it}.dat"

  if not os.path.exists(temp_filename) or not os.path.exists(laplacian_filename):
      print(f"Skipping plot for {it}: Data files missing")
      return

  temp_data = np.loadtxt(temp_filename)
  laplacian_data = np.loadtxt(laplacian_filename)

  y = np.unique(temp_data[:, 0])
  x = np.unique(temp_data[:, 1])

  temp_values = temp_data[:, 2].reshape(len(y), len(x))
  laplacian_values = laplacian_data[:, 2].reshape(len(y), len(x))

  fig, axs = plt.subplots(1, 2, figsize=(12, 6))

  im1 = axs[0].imshow(temp_values, origin='lower', extent=[x.min(), x.max(), y.min(), y.max()], cmap='inferno')
  axs[0].set_title(f"Temperature T(x,y) at it={it}")
  axs[0].set_xlabel('x')
  axs[0].set_ylabel('y')
  fig.colorbar(im1, ax=axs[0])

  im2 = axs[1].imshow(laplacian_values, origin='lower', extent=[x.min(), x.max(), y.min(), y.max()], cmap='inferno')
  axs[1].set_title(f"Laplacian of Temperature  ∇²T(x,y) at it={it}")
  axs[1].set_xlabel('x')
  axs[1].set_ylabel('y')
  fig.colorbar(im2, ax=axs[1])

  plt.tight_layout()

    # Save the plots as PNG files
  plot_filename = f"{file_prefix}_plots_{it}.png"
  plt.savefig(plot_filename)
  plt.close(fig)  # Close figure to free memory
  print(f"Saved plot to {plot_filename}")


if __name__ == "__main__":
    file_prefix = "data"  # Set your file prefix here
    for it in [100, 200, 500, 1000, 2000]:
        plot_and_save_data(file_prefix, it)