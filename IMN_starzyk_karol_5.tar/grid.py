import numpy as np
import matplotlib.pyplot as plt

k_values = [16, 8, 4, 2, 1]
xmax, ymax = 128 * 0.2, 128 * 0.2

potential = np.loadtxt("potential_k16.txt")
plt.figure()
plt.imshow(potential.T, extent=(0, xmax, 0, ymax), origin='lower', cmap='RdBu_r', aspect='equal')
plt.colorbar(label='Potential V(x, y)')
plt.title('Potential map for k = 16')
plt.savefig("potential_map_k16.png", dpi=300)
plt.close()

for k in k_values[1:]:
    potential = np.loadtxt(f"potential_k{k}.txt")
    plt.figure()
    plt.imshow(potential.T, extent=(0, xmax, 0, ymax), origin='lower', cmap='RdBu_r', aspect='equal')
    plt.colorbar(label='Potential V(x, y)')
    plt.title(f'Potential map for k = {k}')
    plt.savefig(f"potential_map_k{k}.png", dpi=300)
    plt.close()

plt.figure(figsize=(10, 6))
for k in k_values:
    S_history = np.loadtxt(f"S_history_k{k}.txt")
    if k == 16:
        plt.plot(S_history, label=f'k = {k}', linewidth=2)
    else:
        plt.plot(S_history, label=f'k = {k}')
plt.xlabel('Iterations')
plt.ylabel('S(k)')
plt.yscale('linear')
plt.xlim(0, 600)
plt.ylim(4.2, 5.6)
plt.title('Change of functional integral S(k) over iterations')
plt.legend()
plt.savefig("global_iterations.png", dpi=300)
plt.close()