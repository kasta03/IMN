#include <vector>
#include <cmath>
#include <fstream>
#include <iostream>
#include <algorithm>

const double epsilon = 1.0;
const double delta = 0.1;
const int nx = 150, ny = 100;
const double xmax = delta * nx, ymax = delta * ny;
const double V1_val = 10.0, V2_val = 0.0;
const double TOL = 1e-8;

const double sigma_x = 0.1 * xmax;
const double sigma_y = 0.1 * ymax;

//helper
double rho(double x, double y) {
    double rho1 = (+1.0) * exp(-((x - 0.35 * xmax) * (x - 0.35 * xmax) / (sigma_x * sigma_x)) 
                               - ((y - 0.5 * ymax) * (y - 0.5 * ymax) / (sigma_y * sigma_y)));
    double rho2 = (-1.0) * exp(-((x - 0.65 * xmax) * (x - 0.65 * xmax) / (sigma_x * sigma_x)) 
                               - ((y - 0.5 * ymax) * (y - 0.5 * ymax) / (sigma_y * sigma_y)));
    return rho1 + rho2;
}

//S
double calculate_S(const std::vector<std::vector<double>>& V, 
                  const std::vector<std::vector<double>>& rho_grid, 
                  double delta) {
    double S = 0.0;
    for (int i = 0; i < nx - 1; ++i) {
        for (int j = 0; j < ny - 1; ++j) {
            double Ex = (V[i + 1][j] - V[i][j]) / delta;
            double Ey = (V[i][j + 1] - V[i][j]) / delta;
            S += delta * delta * (0.5 * (Ex * Ex + Ey * Ey) - rho_grid[i][j] * V[i][j]);
        }
    }
    return S;
}

// Global relaxation
std::pair<std::vector<std::vector<double>>, std::vector<double>> 
global_relaxation(std::vector<std::vector<double>> V, 
                 const std::vector<std::vector<double>>& rho_grid,
                 double omega, double delta, double epsilon, double TOL,
                 int max_iter = 100000) {
    std::vector<double> S_list;
    double S_prev = calculate_S(V, rho_grid, delta);
    
    for (int iteration = 0; iteration < max_iter; ++iteration) {
        std::vector<std::vector<double>> V_new = V;
        
        for (int i = 1; i < nx - 1; ++i) {
            for (int j = 1; j < ny - 1; ++j) {
                V_new[i][j] = 0.25 * (V[i + 1][j] + V[i - 1][j] + V[i][j + 1] + V[i][j - 1] + 
                                     (delta * delta / epsilon) * rho_grid[i][j]);
            }
        }
        
        for (int j = 0; j < ny; ++j) {
            V_new[0][j] = V_new[1][j];
            V_new[nx-1][j] = V_new[nx-2][j];
        }
        
        for (int i = 0; i < nx; ++i) {
            for (int j = 0; j < ny; ++j) {
                V[i][j] = (1 - omega) * V[i][j] + omega * V_new[i][j];
            }
        }
        
        double S_current = calculate_S(V, rho_grid, delta);
        S_list.push_back(S_current);
        
        if (std::abs(S_current - S_prev) / std::abs(S_prev + 1e-10) < TOL) {
            break;
        }
        S_prev = S_current;
    }
    
    return {V, S_list};
}

// Local relaxation
std::pair<std::vector<std::vector<double>>, std::vector<double>> 
local_relaxation(std::vector<std::vector<double>> V, 
                const std::vector<std::vector<double>>& rho_grid,
                double omega, double delta, double epsilon, double TOL,
                int max_iter = 100000) {
    std::vector<double> S_list;
    double S_prev = calculate_S(V, rho_grid, delta);
    
    for (int iteration = 0; iteration < max_iter; ++iteration) {
        for (int i = 1; i < nx - 1; ++i) {
            for (int j = 1; j < ny - 1; ++j) {
                double V_new = 0.25 * (V[i + 1][j] + V[i - 1][j] + V[i][j + 1] + V[i][j - 1] + 
                                     (delta * delta / epsilon) * rho_grid[i][j]);
                V[i][j] = (1 - omega) * V[i][j] + omega * V_new;
            }
        }
        
        for (int j = 0; j < ny; ++j) {
            V[0][j] = V[1][j];
            V[nx-1][j] = V[nx-2][j];
        }
        
        double S_current = calculate_S(V, rho_grid, delta);
        S_list.push_back(S_current);
        
        if (std::abs(S_current - S_prev) / std::abs(S_prev + 1e-10) < TOL) {
            break;
        }
        S_prev = S_current;
    }
    
    return {V, S_list};
}

void save_results(const std::vector<std::vector<double>>& V, 
                 const std::vector<double>& S_list,
                 const std::string& filename) {
    std::ofstream outfile(filename);
    
    for (int i = 0; i < nx; ++i) {
        for (int j = 0; j < ny; ++j) {
            outfile << V[i][j] << " ";
        }
        outfile << "\n";
    }
    outfile << "S_LIST\n";

    for (double s : S_list) {
        outfile << s << "\n";
    }
    outfile.close();
}

int main() {
    // Initialize grids
    std::vector<std::vector<double>> V_initial(nx, std::vector<double>(ny, 0.0));
    std::vector<std::vector<double>> rho_grid(nx, std::vector<double>(ny, 0.0));
    
    // Set initial conditions
    for (int i = 0; i < nx; ++i) {
        V_initial[i][0] = V1_val;
        V_initial[i][ny-1] = V2_val;
    }
    
    // Calculate rho grid
    for (int i = 0; i < nx; ++i) {
        for (int j = 0; j < ny; ++j) {
            double x = i * delta;
            double y = j * delta;
            rho_grid[i][j] = rho(x, y);
        }
    }
    
    // Run relaxation methods
    auto [V_global_0_6, S_global_0_6] = global_relaxation(V_initial, rho_grid, 0.6, delta, epsilon, TOL);
    auto [V_global_1_0, S_global_1_0] = global_relaxation(V_initial, rho_grid, 1.0, delta, epsilon, TOL);
    
    auto [V_local_1_0, S_local_1_0] = local_relaxation(V_initial, rho_grid, 1.0, delta, epsilon, TOL);
    auto [V_local_1_4, S_local_1_4] = local_relaxation(V_initial, rho_grid, 1.4, delta, epsilon, TOL);
    auto [V_local_1_8, S_local_1_8] = local_relaxation(V_initial, rho_grid, 1.8, delta, epsilon, TOL);
    auto [V_local_1_9, S_local_1_9] = local_relaxation(V_initial, rho_grid, 1.9, delta, epsilon, TOL);
    
    // Save results to files
    save_results(V_global_0_6, S_global_0_6, "global_0.6.txt");
    save_results(V_global_1_0, S_global_1_0, "global_1.0.txt");
    save_results(V_local_1_0, S_local_1_0, "local_1.0.txt");
    save_results(V_local_1_4, S_local_1_4, "local_1.4.txt");
    save_results(V_local_1_8, S_local_1_8, "local_1.8.txt");
    save_results(V_local_1_9, S_local_1_9, "local_1.9.txt");
    
    std::ofstream rho_file("rho_grid.txt");
    for (int i = 0; i < nx; ++i) {
        for (int j = 0; j < ny; ++j) {
            rho_file << rho_grid[i][j] << " ";
        }
        rho_file << "\n";
    }
    rho_file.close();
    
    return 0;
}