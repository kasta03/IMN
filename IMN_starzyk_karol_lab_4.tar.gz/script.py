import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, FixedFormatter

def load_results(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    
    # Find separator between V and S_list
    separator_idx = lines.index('S_LIST\n')
    
    # Load potential map
    V = np.array([[float(x) for x in line.strip().split()] 
                  for line in lines[:separator_idx]])
    
    # Load S list
    S_list = [float(line.strip()) for line in lines[separator_idx+1:]]
    
    return V, S_list

def load_rho_grid(filename):
    return np.loadtxt(filename)

# Constants (must match C++ values)
delta = 0.1
nx, ny = 150, 100
xmax, ymax = delta * nx, delta * ny
epsilon = 1.0

# Load results
V_global_0_6, S_global_0_6 = load_results('global_0.6.txt')
V_global_1_0, S_global_1_0 = load_results('global_1.0.txt')
V_local_1_0, S_local_1_0 = load_results('local_1.0.txt')
V_local_1_4, S_local_1_4 = load_results('local_1.4.txt')
V_local_1_8, S_local_1_8 = load_results('local_1.8.txt')
V_local_1_9, S_local_1_9 = load_results('local_1.9.txt')
rho_grid = load_rho_grid('rho_grid.txt')

# Create convergence plots
plt.figure(figsize=(12, 6))

# Global relaxation plot
plt.subplot(1, 2, 1)
plt.plot(range(1, len(S_global_0_6) + 1), S_global_0_6, 
         label=f'ω = 0.6, {len(S_global_0_6)} iterations')
plt.plot(range(1, len(S_global_1_0) + 1), S_global_1_0, 
         label=f'ω = 1.0, {len(S_global_1_0)} iterations')
plt.xlabel('Iterations')
plt.ylabel('S')
plt.xscale('log')
plt.xlim(1, 100000)
ax1 = plt.gca()
major_ticks = [1, 10, 100, 1000, 10000, 100000]
ax1.xaxis.set_major_locator(FixedLocator(major_ticks))
ax1.xaxis.set_major_formatter(FixedFormatter([str(tick) for tick in major_ticks]))
plt.ylim(bottom=0)
plt.legend()
plt.title('Convergence of Function S for Global Relaxation')

# Local relaxation plot
plt.subplot(1, 2, 2)
plt.plot(range(1, len(S_local_1_0) + 1), S_local_1_0, 
         label=f'ω = 1.0, {len(S_local_1_0)} iterations')
plt.plot(range(1, len(S_local_1_4) + 1), S_local_1_4, 
         label=f'ω = 1.4, {len(S_local_1_4)} iterations')
plt.plot(range(1, len(S_local_1_8) + 1), S_local_1_8, 
         label=f'ω = 1.8, {len(S_local_1_8)} iterations')
plt.plot(range(1, len(S_local_1_9) + 1), S_local_1_9, 
         label=f'ω = 1.9, {len(S_local_1_9)} iterations')
plt.xlabel('Iterations')
plt.ylabel('S')
plt.xscale('log')
plt.xlim(1, 100000)
ax2 = plt.gca()
ax2.xaxis.set_major_locator(FixedLocator(major_ticks))
ax2.xaxis.set_major_formatter(FixedFormatter([str(tick) for tick in major_ticks]))
plt.ylim(bottom=0)
plt.legend()
plt.title('Convergence of Function S for Local Relaxation')
plt.tight_layout()
plt.savefig('convergence_plots.png')
plt.show()

def plot_potential_maps(omega_values, V_results, title_prefix, filename_prefix):
    for omega, V in zip(omega_values, V_results):
        plt.figure(figsize=(8, 6))
        plt.imshow(V.T, extent=(0, xmax, 0, ymax), origin='lower', cmap='viridis', aspect='auto')
        plt.colorbar(label='Potential V(x, y)')
        plt.title(f'{title_prefix} (ω = {omega})')
        plt.xlabel('x')
        plt.ylabel('y')
        plt.savefig(f"{filename_prefix}_omega_{omega}.png")
        plt.show()

def plot_error_maps(omega_values, V_results, rho_grid, title_prefix, filename_prefix):
    x_interior = np.linspace(delta, xmax-delta, nx-2)
    y_interior = np.linspace(delta, ymax-delta, ny-2)
    
    for omega, V in zip(omega_values, V_results):
        # Compute Laplacian using finite differences
        laplace_V = np.zeros((nx-2, ny-2))
        for i in range(1, nx-1):
            for j in range(1, ny-1):
                laplace_V[i-1][j-1] = (V[i+1][j] + V[i-1][j] + V[i][j+1] + V[i][j-1] - 4*V[i][j]) / (delta*delta)
        
        # Extract interior points of rho_grid
        rho_interior = rho_grid[1:-1, 1:-1]
        
        # Compute error δ
        error = laplace_V + rho_interior / epsilon
        
        plt.figure(figsize=(8, 6))
        extent = [x_interior[0], x_interior[-1], y_interior[0], y_interior[-1]]
        plt.imshow(error.T, extent=extent, origin='lower', cmap='seismic', aspect='auto')
        plt.colorbar(label='Error δ')
        plt.title(f'{title_prefix} (ω = {omega})')
        plt.xlabel('x')
        plt.ylabel('y')
        plt.savefig(f"{filename_prefix}_omega_{omega}.png")
        plt.show()

# Generate potential maps and error maps
# Global relaxation
plot_potential_maps(
    [0.6, 1.0],
    [V_global_0_6, V_global_1_0],
    "Potential Map - Global Relaxation",
    "global_potential"
)

plot_error_maps(
    [0.6, 1.0],
    [V_global_0_6, V_global_1_0],
    rho_grid,
    "Error Map δ - Global Relaxation",
    "global_error"
)
