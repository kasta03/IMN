Write-Host "Kompilowanie..."
g++ -O2 -o prog prog.cpp

Write-Host "Uruchamianie..."
./prog

Write-Host "Generowania wykresow..."
python plot_res.py

Write-Host "Wyswietlanie wykresow..."
Get-ChildItem *.png | ForEach-Object { code $_.FullName }