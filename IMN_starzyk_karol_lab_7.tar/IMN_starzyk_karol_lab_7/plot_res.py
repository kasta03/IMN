import numpy as np
import matplotlib.pyplot as plt
import os

delta = 0.01
nx = 200
ny = 90

x = np.linspace(0, nx*delta, nx+1)
y = np.linspace(0, ny*delta, ny+1)

def read_binary_solution(filename):
    with open(filename, 'rb') as f:
        data = np.fromfile(f, dtype=np.float64)
    
    matrix_size = (nx+1) * (ny+1)
    u = data[:matrix_size].reshape((nx+1, ny+1))
    v = data[matrix_size:2*matrix_size].reshape((nx+1, ny+1))
    psi = data[2*matrix_size:3*matrix_size].reshape((nx+1, ny+1))
    zeta = data[3*matrix_size:].reshape((nx+1, ny+1))
    
    return u, v, psi, zeta

def plot_results(Q):
    
    filename = f"solution_Q={Q}.bin"
    
    if not os.path.exists(filename):
        print(f"File {filename} not found!")
        return
    
    u, v, psi, zeta = read_binary_solution(filename)
    
    matrices_to_plot = [
        (psi, "psi", "gnuplot", "contour", 50),
        (zeta, "zeta", "gnuplot", "contour", 100),
        (u, "u", "jet", "pcolor", None),
        (v, "v", "jet", "pcolor", None)
    ]
    
    for matrix, name, cmap, plot_type, levels in matrices_to_plot:
        plt.figure(figsize=(12,6))
        
        matrix = np.where(np.isnan(matrix), np.nan, matrix)
        
        if plot_type == "contour":
            plt.contour(
                x, 
                y, 
                matrix.T, 
                vmin=np.nanmin(matrix), 
                vmax=np.nanmax(matrix), 
                cmap=cmap,
                levels=levels
            )
        else:
            plt.pcolormesh(
                x, 
                y, 
                matrix.T, 
                vmin=np.nanmin(matrix), 
                vmax=np.nanmax(matrix), 
                shading="auto", 
                cmap=cmap
            )
        
        plt.xlabel("x")
        plt.ylabel("y")
        plt.colorbar()
        plt.title(f"Q={Q}, {name}(x,y)")
        
        plt.savefig(f"{name}_q_{Q}.png")
        plt.close()
    
    print(f"Q = {Q} pplot saved.")

def main():
    Q_values = [-1000, -4000, 4000]
    
    for Q in Q_values:
        plot_results(Q)

if __name__ == "__main__":
    main()