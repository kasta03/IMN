#include <iostream>
#include <vector>
#include <cmath>
#include <fstream>
#include <array>
#include <limits>
#include <sstream>


class FluidSimulation {
private:
    // Parametry
    const double delta = 0.01;
    const double rho = 1.0;
    const double mi = 1.0;
    const int nx = 200;
    const int ny = 90;
    const int i_1 = 50;
    const int j_1 = 55;
    const int j_2 = j_1 + 2;
    const int IT_MAX = 20000;

    // Funkcje pomocnicze
    typedef std::vector<std::vector<double>> Matrix;

    Matrix createMatrix(int rows, int cols, double initValue = 0.0) {
        return Matrix(rows, std::vector<double>(cols, initValue));
    }

    bool isOnBoundary(int i, int j) {
        if (i == 0 && j >= j_1 && j <= ny) return true;
        if (j == ny) return true;
        if (i == nx) return true;
        if (i >= i_1 && i <= nx && j == 0) return true;
        if (i <= i_1 && j == j_1) return true;
        if (i == i_1 && j >= 0 && j <= j_1) return true;
        return false;
    }

    void setBoundaryPsi(Matrix& psi, double Q) {
        double y_ny = delta * ny;
        double y_j_1 = delta * j_1;
        double Qwy = Q * (std::pow(y_ny, 3) - std::pow(y_j_1, 3) - 3 * y_j_1 * std::pow(y_ny, 2) + 3 * std::pow(y_j_1, 2) * y_ny) / std::pow(y_ny, 3);

        // A
        for (int j = j_1; j <= ny; ++j) {
            double y_val = j * delta;
            psi[0][j] = Q / (2 * mi) * (std::pow(y_val, 3) / 3 - 
                ((std::pow(y_val, 2) / 2) * (y_j_1 + y_ny)) + y_val * y_j_1 * y_ny);
        }

        // C
        for (int j = 0; j <= ny; ++j) {
            double y_val = j * delta;
            psi[nx][j] = Qwy / (2 * mi) * (std::pow(y_val, 3) / 3 - 
                (std::pow(y_val, 2) * (y_ny / 2))) + 
                ((Q * std::pow(y_j_1, 2) * (-y_j_1 + 3 * y_ny)) / (12 * mi));
        }

        // B
        for (int i = 1; i < nx; ++i) {
            psi[i][ny] = psi[0][ny];
        }

        // D
        for (int i = i_1; i < nx; ++i) {
            psi[i][0] = psi[0][j_1];
        }

        // E
        for (int j = 1; j <= j_1; ++j) {
            psi[i_1][j] = psi[0][j_1];
        }

        // F
        for (int i = 1; i <= i_1; ++i) {
            psi[i][j_1] = psi[0][j_1];
        }
    }

    void setBoundaryZeta(Matrix& zeta, const Matrix& psi, double Q) {
        double y_ny = delta * ny;
        double y_j_1 = delta * j_1;
        double Qwy = Q * (std::pow(y_ny, 3) - std::pow(y_j_1, 3) - 3 * y_j_1 * std::pow(y_ny, 2) + 3 * std::pow(y_j_1, 2) * y_ny) / std::pow(y_ny, 3);

        // A
        for (int j = j_1; j <= ny; ++j) {
            double y_val = delta * j;
            zeta[0][j] = (Q / (2 * mi)) * (2 * y_val - y_j_1 - y_ny);
        }

        // C
        for (int j = 0; j <= ny; ++j) {
            double y_val = delta * j;
            zeta[nx][j] = (Qwy / (2 * mi)) * (2 * y_val - y_ny);
        }

        // B
        for (int i = 1; i < nx; ++i) {
            zeta[i][ny] = 2 / (delta * delta) * (psi[i][ny-1] - psi[i][ny]);
        }

        // D
        for (int i = i_1 + 1; i < nx; ++i) {
            zeta[i][0] = 2 / (delta * delta) * (psi[i][1] - psi[i][0]);
        }

        // E
        for (int j = 1; j < j_1; ++j) {
            zeta[i_1][j] = 2 / (delta * delta) * (psi[i_1+1][j] - psi[i_1][j]);
        }

        // F
        for (int i = 1; i <= i_1; ++i) {
            zeta[i][j_1] = 2 / (delta * delta) * (psi[i][j_1+1] - psi[i][j_1]);
        }

        zeta[i_1][j_1] = 0.5 * (zeta[i_1-1][j_1] + zeta[i_1][j_1-1]);
    }

public:
    std::array<Matrix, 4> relaxation(double Q) {
        // Inicjalizacja macierzy
        Matrix u = createMatrix(nx+1, ny+1, 0.0);
        Matrix v = createMatrix(nx+1, ny+1, 0.0);
        Matrix psi = createMatrix(nx+1, ny+1, 0.0);
        Matrix zeta = createMatrix(nx+1, ny+1, 0.0);

        const double WALL_MARKER = std::numeric_limits<double>::quiet_NaN();
        for (int i = 0; i < i_1; ++i) {
            for (int j = 0; j < j_1; ++j) {
                psi[i][j] = WALL_MARKER;
                zeta[i][j] = WALL_MARKER;
            }
        }

        // Ustawienie dla psi
        setBoundaryPsi(psi, Q);

        std::vector<double> gamma_values;

        for (int it = 1; it <= IT_MAX; ++it) {
            for (int i = 1; i < nx; ++i) {
                for (int j = 1; j < ny; ++j) {
                    if (!isOnBoundary(i, j)) {
                        psi[i][j] = (psi[i+1][j] + psi[i-1][j] + psi[i][j+1] + psi[i][j-1] - 
                                     (delta * delta) * zeta[i][j]) / 4.0;
                        
                        zeta[i][j] = 0.25 * (zeta[i+1][j] + zeta[i-1][j] + zeta[i][j+1] + zeta[i][j-1]);
                        
                        if (it > 2000) {
                            zeta[i][j] -= ((rho / (16 * mi)) * 
                                ((psi[i][j+1] - psi[i][j-1]) * (zeta[i+1][j] - zeta[i-1][j]) -
                                 (psi[i+1][j] - psi[i-1][j]) * (zeta[i][j+1] - zeta[i][j-1])));
                        }
                    }
                }
            }

            setBoundaryZeta(zeta, psi, Q);

            double gamma = 0.0;
            for (int i = 1; i < nx; ++i) {
                gamma += (psi[i+1][j_2] + psi[i-1][j_2] + psi[i][j_2+1] + psi[i][j_2-1] - 
                          4 * psi[i][j_2] - (delta * delta) * zeta[i][j_2]);
            }
            gamma_values.push_back(gamma);
        }

        // Obliczanie składowych prędkości
        for (int i = 1; i < nx; ++i) {
            for (int j = 1; j < ny; ++j) {
                if (i > i_1 || j > j_1) {
                    u[i][j] = (psi[i][j+1] - psi[i][j-1]) / (2.0 * delta);
                    v[i][j] = -(psi[i+1][j] - psi[i-1][j]) / (2.0 * delta);
                }
            }
        }

        int Q_int = static_cast<int>(Q);
        // Zapis błędu
        std::ofstream error_file("error_Q=" + std::to_string(Q_int) + ".txt");
        for (size_t it = 0; it < gamma_values.size(); ++it) {
            error_file << "Iteracja=" << it+1 << ", błąd: " << gamma_values[it] << std::endl;
        }
        error_file.close();

        // Zapis danych do bin
        std::ofstream solution_file("solution_Q=" + std::to_string(Q_int) + ".bin", std::ios::binary);
        for (const auto& matrix : {u, v, psi, zeta}) {
            for (const auto& row : matrix) {
                solution_file.write(reinterpret_cast<const char*>(row.data()), row.size() * sizeof(double));
            }
        }
        solution_file.close();

        return {u, v, psi, zeta};
    }
};

int main() {
    FluidSimulation sim;
    std::array<int, 3> Q_values = {-1000, -4000, 4000};

    for (int Q : Q_values) {
        std::cout << Q << std::endl;
        sim.relaxation(Q);
    }

    return 0;
}
