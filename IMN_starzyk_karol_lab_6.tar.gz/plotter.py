import numpy as np
import matplotlib.pyplot as plt

def read_solution(filename):
    with open(filename, 'r') as f:
        # Skip first line (comment)
        f.readline()
        
        # Read parameters
        params = list(map(float, f.readline().strip().split()))
        nx, ny = int(params[0]), int(params[1])
        epsilon1, epsilon2 = params[2], params[3]
        v1, v2, v3, v4 = params[4:8]
        use_function_rho = bool(int(params[8]))
        
        # Skip empty line and comment
        f.readline()
        f.readline()
        
        # Read solution matrix
        V = np.zeros((ny + 1, nx + 1))
        for j in range(ny + 1):
            V[j] = list(map(float, f.readline().strip().split()))
            
        return V, nx, ny, epsilon1, epsilon2, use_function_rho

def plot_solution(solution_filename, plot_filename, vmin=-10, vmax=10):
    # Read solution and parameters
    V, nx, ny, epsilon1, epsilon2, use_function_rho = read_solution(solution_filename)
    
    # Calculate dimensions
    DELTA = 0.1
    xmax = DELTA * nx
    ymax = DELTA * ny
    
    # Adjust vmin and vmax for rho cases
    if use_function_rho:
        vmin, vmax = -0.8, 0.8
    
    # Create title based on parameters
    if use_function_rho:
        title = fr"$\epsilon_1={epsilon1}, \epsilon_2={epsilon2}$"
    else:
        title = fr"$nx=ny={nx}, \epsilon_1={epsilon1}, \epsilon_2={epsilon2}$"
    
    # Create the plot
    plt.figure(figsize=(8, 6))
    img = plt.imshow(V, extent=(0, xmax, 0, ymax), origin='lower', 
                    cmap='bwr', vmin=vmin, vmax=vmax, aspect='equal')
    plt.colorbar(img, label='V')
    plt.title(title)
    plt.xlabel('x')
    plt.ylabel('y')
    
    # Save plot to file and close the figure
    plt.savefig(plot_filename, dpi=300, bbox_inches='tight')
    plt.close()

def main():
    # Plot all cases
    cases = ["case1", "case2", "case3", "case4", "case5", "case6", "check_4x4"]
    
    for case in cases:
        print(f"Plotting {case}...")
        solution_filename = f"solution_{case}.txt"
        plot_filename = f"plot_{case}.png"
        plot_solution(solution_filename, plot_filename)

if __name__ == "__main__":
    main()