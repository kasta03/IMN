#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <string>

const double DELTA = 0.1;
const double SIGMA_SCALE = 10.0;
const double V1_DEFAULT = 10.0;
const double V2_DEFAULT = -10.0;
const double V3_DEFAULT = 10.0;
const double V4_DEFAULT = -10.0;
const double TOLERANCE = 1e-6;
const int MAX_ITERATIONS = 10000;

double rho1(int i, int j, double xmax, double ymax, double sigma) {
    return exp(-pow((i * DELTA - 0.25 * xmax) / sigma, 2) - 
               pow((j * DELTA - 0.5 * ymax) / sigma, 2));
}

double rho2(int i, int j, double xmax, double ymax, double sigma) {
    return -exp(-pow((i * DELTA - 0.75 * xmax) / sigma, 2) - 
                pow((j * DELTA - 0.5 * ymax) / sigma, 2));
}

double rho(int i, int j, double xmax, double ymax, double sigma) {
    return rho1(i, j, xmax, ymax, sigma) + rho2(i, j, xmax, ymax, sigma);
}

// Gauss-Seidel iteration for Poisson equation
void solve_poisson(int nx, int ny, double epsilon1, double epsilon2,
                  double v1, double v2, double v3, double v4,
                  bool use_function_rho, const std::string& filename) {
    double xmax = DELTA * nx;
    double ymax = DELTA * ny;
    double sigma = xmax / SIGMA_SCALE;
    
    // Initialize solution arrays (current and previous iteration)
    std::vector<std::vector<double>> V(ny + 1, std::vector<double>(nx + 1, 0.0));
    std::vector<std::vector<double>> V_old(ny + 1, std::vector<double>(nx + 1, 0.0));
    
    // Set initial boundary conditions
    for (int i = 0; i <= nx; i++) {
        V[0][i] = v4;      // bottom
        V[ny][i] = v2;     // top
    }
    for (int j = 0; j <= ny; j++) {
        V[j][0] = v1;      // left
        V[j][nx] = v3;     // right
    }
    
    // Iterative solution
    double max_diff;
    int iteration = 0;
    do {
        // Save previous iteration
        V_old = V;
        max_diff = 0.0;
        
        // Update interior points
        for (int j = 1; j < ny; j++) {
            for (int i = 1; i < nx; i++) {
                if (use_function_rho) {
                    double rho_val = rho(i, j, xmax, ymax, sigma);
                    double epsilon_c = (i <= nx/2) ? epsilon1 : epsilon2;
                    double epsilon_l = (i-1 <= nx/2) ? epsilon1 : epsilon2;
                    double epsilon_r = (i+1 <= nx/2) ? epsilon1 : epsilon2;
                    
                    double eps_x_l = (epsilon_c + epsilon_l) / 2.0;
                    double eps_x_r = (epsilon_c + epsilon_r) / 2.0;
                    
                    V[j][i] = (
                        eps_x_l * V[j][i-1] + 
                        eps_x_r * V[j][i+1] + 
                        epsilon_c * (V[j-1][i] + V[j+1][i]) +
                        DELTA * DELTA * rho_val
                    ) / (2.0 * (eps_x_l + eps_x_r));
                } else {
                    double epsilon_c = (i <= nx/2) ? epsilon1 : epsilon2;
                    double epsilon_l = (i-1 <= nx/2) ? epsilon1 : epsilon2;
                    double epsilon_r = (i+1 <= nx/2) ? epsilon1 : epsilon2;
                    
                    double eps_x_l = (epsilon_c + epsilon_l) / 2.0;
                    double eps_x_r = (epsilon_c + epsilon_r) / 2.0;
                    
                    V[j][i] = (
                        eps_x_l * V[j][i-1] + 
                        eps_x_r * V[j][i+1] + 
                        epsilon_c * (V[j-1][i] + V[j+1][i])
                    ) / (2.0 * (eps_x_l + eps_x_r));
                }
                
                double diff = fabs(V[j][i] - V_old[j][i]);
                if (diff > max_diff) max_diff = diff;
            }
        }
        
        iteration++;
    } while (max_diff > TOLERANCE && iteration < MAX_ITERATIONS);
    
    // Save to file
    std::ofstream outfile(filename);
    outfile.precision(6);
    outfile << "# Parameters:\n";
    outfile << nx << " " << ny << " " << epsilon1 << " " << epsilon2 << " "
            << v1 << " " << v2 << " " << v3 << " " << v4 << " "
            << (use_function_rho ? 1 : 0) << "\n\n";
    
    outfile << "# Solution matrix:\n";
    for (int j = 0; j <= ny; j++) {
        for (int i = 0; i <= nx; i++) {
            outfile << V[j][i] << " ";
        }
        outfile << "\n";
    }
    outfile.close();
    
    std::cout << "Case finished after " << iteration << " iterations. Max diff: " << max_diff << std::endl;
}

int main() {
    struct Case {
        std::string name;
        int nx_ny;
        double epsilon1, epsilon2;
        bool use_rho;
        double v1, v2, v3, v4;
    };

    std::vector<Case> cases = {
        {"case1", 50, 1.0, 1.0, false, V1_DEFAULT, V2_DEFAULT, V3_DEFAULT, V4_DEFAULT},
        {"case2", 100, 1.0, 1.0, false, V1_DEFAULT, V2_DEFAULT, V3_DEFAULT, V4_DEFAULT},
        {"case3", 200, 1.0, 1.0, false, V1_DEFAULT, V2_DEFAULT, V3_DEFAULT, V4_DEFAULT},
        {"case4", 100, 1.0, 1.0, true, 0.0, 0.0, 0.0, 0.0},
        {"case5", 100, 1.0, 2.0, true, 0.0, 0.0, 0.0, 0.0},
        {"case6", 100, 1.0, 10.0, true, 0.0, 0.0, 0.0, 0.0}
    };

    for (const auto& case_ : cases) {
        std::cout << "Solving " << case_.name << "..." << std::endl;
        solve_poisson(
            case_.nx_ny, case_.nx_ny,
            case_.epsilon1, case_.epsilon2,
            case_.v1, case_.v2, case_.v3, case_.v4,
            case_.use_rho,
            "solution_" + case_.name + ".txt"
        );
    }

    // Additional case for nx=ny=4
    std::cout << "Solving check_4x4..." << std::endl;
    solve_poisson(4, 4, 1.0, 1.0, 10.0, -10.0, 10.0, -10.0, false, "solution_check_4x4.txt");

    return 0;
}