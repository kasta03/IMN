import math
import matplotlib.pyplot as plt
import numpy as np

# Derivative_function
def derivative_function(diff, Y):
    return diff * Y

# Analytical Function
def analytical_function(diff, t):
    return math.e ** (diff * t)

# Euler
def euler_method():
    diff = -1
    time_steps = [0.01, 0.1, 1.0]
    y_initial = 1
    start = 0
    end = 5

    def compute_euler_step(y, dt):
        return y + dt * derivative_function(diff, y)

    def compute_error(y, t):
        return y - analytical_function(diff, t)

    results = {}
    for dt in time_steps:
        t_array = np.append(np.arange(start, end, dt), end)
        y_array = [y_initial]
        error = [0]

        for t in t_array[1:]:
            index = len(y_array)
            y_array.append(compute_euler_step(y_array[index - 1], dt))
            error.append(compute_error(y_array[-1], t))

        results[dt] = (t_array, y_array, error)
    return results

# RK2
def rk2_method():
    diff = -1
    time_steps = [0.01, 0.1, 1.0]
    y_initial = 1
    start = 0
    end = 5

    def compute_rk2_step(y, dt):
        k1 = derivative_function(diff, y)
        k2 = derivative_function(diff, y + dt * k1)
        return y + dt / 2 * (k1 + k2)

    def compute_error(y, t):
        return y - analytical_function(diff, t)

    results = {}
    for dt in time_steps:
        t_array = np.append(np.arange(start, end, dt), end)
        y_array = [y_initial]
        error = [0]

        for t in t_array[1:]:
            index = len(y_array)
            y_array.append(compute_rk2_step(y_array[index - 1], dt))
            error.append(compute_error(y_array[-1], t))

        results[dt] = (t_array, y_array, error)
    return results

# RK4 
def rk4_method():
    diff = -1
    time_steps = [0.01, 0.1, 1.0]
    y_initial = 1
    start = 0
    end = 5

    def compute_rk4_step(y, dt):
        k1 = derivative_function(diff, y)
        k2 = derivative_function(diff, y + dt * k1 / 2)
        k3 = derivative_function(diff, y + dt * k2 / 2)
        k4 = derivative_function(diff, y + dt * k3)
        return y + dt / 6 * (k1 + 2 * k2 + 2 * k3 + k4)

    def compute_error(y, t):
        return y - analytical_function(diff, t)

    results = {}
    for dt in time_steps:
        t_array = np.append(np.arange(start, end, dt), end)
        y_array = [y_initial]
        error = [0]

        for t in t_array[1:]:
            index = len(y_array)
            y_array.append(compute_rk4_step(y_array[index - 1], dt))
            error.append(compute_error(y_array[-1], t))

        results[dt] = (t_array, y_array, error)
    return results

# RLC Circuit using RK4
def V(t, frequency):
    return 10 * np.sin(frequency * t)

def rlc_circuit():
    R = 100
    L = 0.1
    C = 0.001
    Q_initial = 0
    I_initial = 0
    frequencies = [0.5, 0.8, 1.0, 1.2]
    dt = 0.0001

    results = {}
    for w in frequencies:
        w0 = 1 / math.sqrt(L * C)
        start = 0
        end = 4 * 2 * math.pi / w0
        t_values = np.arange(start, end + dt, dt)
        Q = [Q_initial]
        I = [I_initial]

        for t in range(len(t_values) - 1):
            kq1 = I[t]
            ki1 = V(t * dt, w * w0) / L - Q[t] / (L * C) - R * I[t] / L
            kq2 = I[t] + dt * ki1 / 2
            ki2 = V((t + 0.5) * dt, w * w0) / L - (Q[t] + kq1 * dt / 2) / (L * C) - R * (I[t] + ki1 * dt / 2) / L
            kq3 = I[t] + dt * ki2 / 2
            ki3 = V((t + 0.5) * dt, w * w0) / L - (Q[t] + kq2 * dt / 2) / (L * C) - R * (I[t] + ki2 * dt / 2) / L
            kq4 = I[t] + dt * ki3
            ki4 = V((t + 1) * dt, w * w0) / L - (Q[t] + kq3 * dt) / (L * C) - R * (I[t] + ki3 * dt) / L
            Q.append(Q[t] + (kq1 + 2 * kq2 + 2 * kq3 + kq4) * dt / 6)
            I.append(I[t] + (ki1 + 2 * ki2 + 2 * ki3 + ki4) * dt / 6)

        results[w] = (t_values, Q, I)
    return results

# Create a figure
fig, axs = plt.subplots(3, 3, figsize=(15, 10))

# Run methods
euler_results = euler_method()
rk2_results = rk2_method()
rk4_results = rk4_method()
rlc_results = rlc_circuit()

# Define a colors
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22']

# Plot results for Euler method
for i, (dt, (t_array, y_array, error)) in enumerate(euler_results.items()):
    axs[0, 0].scatter(t_array, y_array, label=f'dt={dt}', color=colors[i % len(colors)])
    if dt == 0.01:
        axs[0, 0].plot(t_array, [analytical_function(-1, t) for t in t_array], 'k--', label='Exact')
axs[0, 0].set_title('Euler Method')
axs[0, 0].set_xlabel('t')
axs[0, 0].set_ylabel('y(t)')
axs[0, 0].grid(True)
axs[0, 0].legend()

# Plot global error for Euler method
for i, (dt, (t_array, y_array, error)) in enumerate(euler_results.items()):
    axs[1, 0].plot(t_array, error, label=f'dt={dt}', color=colors[i % len(colors)])
axs[1, 0].set_title('Global Error - Euler Method')
axs[1, 0].set_xlabel('t')
axs[1, 0].set_ylabel('y(t) - y_exact(t)')
axs[1, 0].grid(True)
axs[1, 0].legend()

# Plot results for RK2 method
for i, (dt, (t_array, y_array, error)) in enumerate(rk2_results.items()):
    axs[0, 1].scatter(t_array, y_array, label=f'dt={dt}', color=colors[i % len(colors)])
    if dt == 0.01:
        axs[0, 1].plot(t_array, [analytical_function(-1, t) for t in t_array], 'k--', label='Exact')
axs[0, 1].set_title('RK2 Method')
axs[0, 1].set_xlabel('t')
axs[0, 1].set_ylabel('y(t)')
axs[0, 1].grid(True)
axs[0, 1].legend()

# Plot global error for RK2 method
for i, (dt, (t_array, y_array, error)) in enumerate(rk2_results.items()):
    axs[1, 1].plot(t_array, error, label=f'dt={dt}', color=colors[i % len(colors)])
axs[1, 1].set_title('Global Error - RK2 Method')
axs[1, 1].set_xlabel('t')
axs[1, 1].set_ylabel('y(t) - y_exact(t)')
axs[1, 1].grid(True)
axs[1, 1].legend()

# Plot results for RK4 method
for i, (dt, (t_array, y_array, error)) in enumerate(rk4_results.items()):
    axs[0, 2].scatter(t_array, y_array, label=f'dt={dt}', color=colors[i % len(colors)])
    if dt == 0.01:
        axs[0, 2].plot(t_array, [analytical_function(-1, t) for t in t_array], 'k--', label='Exact')
axs[0, 2].set_title('RK4 Method')
axs[0, 2].set_xlabel('t')
axs[0, 2].set_ylabel('y(t)')
axs[0, 2].grid(True)
axs[0, 2].legend()

# Plot global error for RK4 method
for i, (dt, (t_array, y_array, error)) in enumerate(rk4_results.items()):
    axs[1, 2].plot(t_array, error, label=f'dt={dt}', color=colors[i % len(colors)])
axs[1, 2].set_title('Global Error - RK4 Method')
axs[1, 2].set_xlabel('t')
axs[1, 2].set_ylabel('y(t) - y_exact(t)')
axs[1, 2].grid(True)
axs[1, 2].legend()

# Plot RLC Circuit Results
for i, (frequency, (t_values, Q, I)) in enumerate(rlc_results.items()):
    axs[2, 0].plot(t_values, Q, label=f'Frequency = {frequency} Hz', color=colors[i % len(colors)])
axs[2, 0].set_title('Charge in RLC Circuit')
axs[2, 0].set_xlabel('Time (s)')
axs[2, 0].set_ylabel('Charge (Q)')
axs[2, 0].grid(True)
axs[2, 0].legend()

# Plot RLC Circuit Results
for i, (frequency, (t_values, Q, I)) in enumerate(rlc_results.items()):
    axs[2, 1].plot(t_values, I, label=f'Frequency = {frequency} Hz', color=colors[i % len(colors)])
axs[2, 1].set_title('Current in RLC Circuit')
axs[2, 1].set_xlabel('Time (s)')
axs[2, 1].set_ylabel('Current (I)')
axs[2, 1].grid(True)
axs[2, 1].legend()

plt.savefig('plots.png', dpi=300)