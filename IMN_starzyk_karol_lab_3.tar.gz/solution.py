import matplotlib.pyplot as plt
import numpy as np

def rk2_krok(x, v, dt, alfa):
    k1x = v
    k1v = alfa * (1 - x**2) * v - x
    k2x = v + dt * k1v
    k2v = alfa * (1 - (x + dt * k1x)**2) * (v + dt * k1v) - (x + dt * k1x)
    x_nowe = x + (dt / 2) * (k1x + k2x)
    v_nowe = v + (dt / 2) * (k1v + k2v)
    return x_nowe, v_nowe

def trapez_krok(x, v, dt, alfa):
    x_pred = x + v * dt
    v_pred = v + (alfa * (1 - x**2) * v - x) * dt
    x_nowe = x + (v + v_pred) * dt / 2
    v_nowe = v + (alfa * (1 - x**2) * v - x + alfa * (1 - x_pred**2) * v_pred - x_pred) * dt / 2
    return x_nowe, v_nowe

def rozwiaz_van_der_pol_rk2(tol, alfa=5.0, dt0=1.0, tmax=40.0, x0=0.01, v0=0.0):
    t_punkty, x_punkty, v_punkty, dt_punkty = [0.0], [x0], [v0], [dt0]
    t, x, v, dt = 0.0, x0, v0, dt0
    S, p = 0.75, 2
    while t < tmax:
        x1, v1 = rk2_krok(x, v, dt, alfa)
        x2, v2 = rk2_krok(x1, v1, dt, alfa)
        x_duzy, v_duzy = rk2_krok(x, v, 2 * dt, alfa)
        Ex, Ev = (x2 - x_duzy) / (2**p - 1), (v2 - v_duzy) / (2**p - 1)
        blad = max(abs(Ex), abs(Ev))
        dt_nowe = dt * (S * tol / blad)**(1 / (p + 1))
        dt_nowe = min(dt_nowe, 1.0)
        if blad < tol:
            t += 2 * dt
            x, v = x2, v2
            t_punkty.append(t)
            x_punkty.append(x)
            v_punkty.append(v)
            dt_punkty.append(dt)
        dt = dt_nowe
    return np.array(t_punkty), np.array(x_punkty), np.array(v_punkty), np.array(dt_punkty)

def rozwiaz_van_der_pol_trapez(tol, alfa=5.0, dt0=1.0, tmax=40.0, x0=0.01, v0=0.0):
    t_punkty, x_punkty, v_punkty, dt_punkty = [0.0], [x0], [v0], [dt0]
    t, x, v, dt = 0.0, x0, v0, dt0
    S, p = 0.75, 2
    while t < tmax:
        x1, v1 = trapez_krok(x, v, dt, alfa)
        x2, v2 = trapez_krok(x1, v1, dt, alfa)
        x_duzy, v_duzy = trapez_krok(x, v, 2 * dt, alfa)
        Ex, Ev = (x2 - x_duzy) / (2**p - 1), (v2 - v_duzy) / (2**p - 1)
        blad = max(abs(Ex), abs(Ev))
        dt_nowe = dt * (S * tol / blad)**(1 / (p + 1))
        dt_nowe = min(dt_nowe, 1.0)
        if blad < tol:
            t += 2 * dt
            x, v = x2, v2
            t_punkty.append(t)
            x_punkty.append(x)
            v_punkty.append(v)
            dt_punkty.append(dt)
        dt = dt_nowe
    return np.array(t_punkty), np.array(x_punkty), np.array(v_punkty), np.array(dt_punkty)
import numpy as np
import matplotlib.pyplot as plt

def rk2_krok(x, v, dt, alfa):
    k1x = v
    k1v = alfa * (1 - x**2) * v - x
    k2x = v + dt * k1v
    k2v = alfa * (1 - (x + dt * k1x)**2) * (v + dt * k1v) - (x + dt * k1x)
    x_nowe = x + (dt / 2) * (k1x + k2x)
    v_nowe = v + (dt / 2) * (k1v + k2v)
    return x_nowe, v_nowe

def trapez_krok(x, v, dt, alfa):
    x_pred = x + v * dt
    v_pred = v + (alfa * (1 - x**2) * v - x) * dt
    x_nowe = x + (v + v_pred) * dt / 2
    v_nowe = v + (alfa * (1 - x**2) * v - x + alfa * (1 - x_pred**2) * v_pred - x_pred) * dt / 2
    return x_nowe, v_nowe

def rozwiaz_van_der_pol_rk2(tol, alfa=5.0, dt0=1.0, tmax=40.0, x0=0.01, v0=0.0):
    t_punkty, x_punkty, v_punkty, dt_punkty = [0.0], [x0], [v0], [dt0]
    t, x, v, dt = 0.0, x0, v0, dt0
    S, p = 0.75, 2
    while t < tmax:
        x1, v1 = rk2_krok(x, v, dt, alfa)
        x2, v2 = rk2_krok(x1, v1, dt, alfa)
        x_duzy, v_duzy = rk2_krok(x, v, 2 * dt, alfa)
        Ex, Ev = (x2 - x_duzy) / (2**p - 1), (v2 - v_duzy) / (2**p - 1)
        blad = max(abs(Ex), abs(Ev))
        dt_nowe = dt * (S * tol / blad)**(1 / (p + 1))
        dt_nowe = min(dt_nowe, 1.0)
        if blad < tol:
            t += 2 * dt
            x, v = x2, v2
            t_punkty.append(t)
            x_punkty.append(x)
            v_punkty.append(v)
            dt_punkty.append(dt)
        dt = dt_nowe
    return np.array(t_punkty), np.array(x_punkty), np.array(v_punkty), np.array(dt_punkty)

def rozwiaz_van_der_pol_trapez(tol, alfa=5.0, dt0=1.0, tmax=40.0, x0=0.01, v0=0.0):
    t_punkty, x_punkty, v_punkty, dt_punkty = [0.0], [x0], [v0], [dt0]
    t, x, v, dt = 0.0, x0, v0, dt0
    S, p = 0.75, 2
    while t < tmax:
        x1, v1 = trapez_krok(x, v, dt, alfa)
        x2, v2 = trapez_krok(x1, v1, dt, alfa)
        x_duzy, v_duzy = trapez_krok(x, v, 2 * dt, alfa)
        Ex, Ev = (x2 - x_duzy) / (2**p - 1), (v2 - v_duzy) / (2**p - 1)
        blad = max(abs(Ex), abs(Ev))
        dt_nowe = dt * (S * tol / blad)**(1 / (p + 1))
        dt_nowe = min(dt_nowe, 1.0)
        if blad < tol:
            t += 2 * dt
            x, v = x2, v2
            t_punkty.append(t)
            x_punkty.append(x)
            v_punkty.append(v)
            dt_punkty.append(dt)
        dt = dt_nowe
    return np.array(t_punkty), np.array(x_punkty), np.array(v_punkty), np.array(dt_punkty)

# Set up plotting
fig, axs = plt.subplots(2, 4, figsize=(18, 10))
fig.suptitle('Porównanie Metod RK2 i Trapezów')

t, x, v, dt = rozwiaz_van_der_pol_rk2(1e-2)
axs[0, 0].plot(t, x, color='red', label='TOL=10^-2')
axs[0, 1].plot(t, v, color='red', label='TOL=10^-2')
axs[0, 2].plot(t, dt, color='red', label='TOL=10^-2')
axs[0, 3].plot(x, v, color='red', label='TOL=10^-2')

t, x, v, dt = rozwiaz_van_der_pol_rk2(1e-5)
axs[0, 0].plot(t, x, color='blue', label='TOL=10^-5')
axs[0, 1].plot(t, v, color='blue', label='TOL=10^-5')
axs[0, 2].plot(t, dt, color='blue', label='TOL=10^-5')
axs[0, 3].plot(x, v, color='blue', label='TOL=10^-5')

t, x, v, dt = rozwiaz_van_der_pol_trapez(1e-2)
axs[1, 0].plot(t, x, color='red', label='TOL=10^-2')
axs[1, 1].plot(t, v, color='red', label='TOL=10^-2')
axs[1, 2].plot(t, dt, color='red', label='TOL=10^-2')
axs[1, 3].plot(x, v, color='red', label='TOL=10^-2')

t, x, v, dt = rozwiaz_van_der_pol_trapez(1e-5)
axs[1, 0].plot(t, x, color='blue', label='TOL=10^-5')
axs[1, 1].plot(t, v, color='blue', label='TOL=10^-5')
axs[1, 2].plot(t, dt, color='blue', label='TOL=10^-5')
axs[1, 3].plot(x, v, color='blue', label='TOL=10^-5')

axs[0, 0].set(xlabel='t', ylabel='x(t)', title='RK2')
axs[0, 1].set(xlabel='t', ylabel='v(t)', title='RK2')
axs[0, 2].set(xlabel='t', ylabel='dt(t)', title='RK2')
axs[0, 3].set(xlabel='x', ylabel='v', title='RK2')

axs[1, 0].set(xlabel='t', ylabel='x(t)', title='Trapezów')
axs[1, 1].set(xlabel='t', ylabel='v(t)', title='Trapezów')
axs[1, 2].set(xlabel='t', ylabel='dt(t)', title='Trapezów')
axs[1, 3].set(xlabel='x', ylabel='v', title='Trapezów')

for ax_row in axs:
    for ax in ax_row:
        ax.grid(True)
        ax.legend()

plt.tight_layout(rect=[0, 0.03, 1, 0.95])

# Save and display the plot
nazwa_pliku = "plots.png"
plt.savefig(nazwa_pliku)
plt.show()
