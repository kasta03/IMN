import numpy as np
import matplotlib.pyplot as plt
import math

def met_picarda(zainfekowani_initially, beta=0.001, gamma=0.1, N=500, time_step=0.1, czas_max=100, tolerancja=1e-6, max_iteracje=20):
    """Rozwiązanie metodą trapezoidalną z iteracją Picarda."""
    steps = int(czas_max / time_step)
    czas = np.linspace(0, czas_max, steps + 1)
    zainfekowani = np.zeros(steps + 1)
    zainfekowani[0] = zainfekowani_initially
    alpha = beta * N - gamma
    
    for n in range(steps):
        zainfekowani_init = zainfekowani[n]
        zainfekowani_new = zainfekowani_init
        
        for _ in range(max_iteracje):
            zainfekowani_nastepni = zainfekowani[n] + (time_step / 2) * (
                (alpha * zainfekowani[n] - beta * zainfekowani[n]**2) + 
                (alpha * zainfekowani_new - beta * zainfekowani_new**2)
            )
            
            if math.fabs(zainfekowani_nastepni - zainfekowani_new) < tolerancja:
                print(_)
                break
                
            zainfekowani_new = zainfekowani_nastepni
            print(_)
            
        zainfekowani[n + 1] = zainfekowani_new
        
    return czas, zainfekowani

def met_newtona(zainfekowani_initially, beta=0.001, gamma=0.1, N=500, time_step=0.1, czas_max=100, tolerancja=1e-6, max_iteracje=20):
    """Rozwiązanie metodą trapezoidalną z iteracją Newtona."""
    steps = int(czas_max / time_step)
    czas = np.linspace(0, czas_max, steps + 1)
    zainfekowani = np.zeros(steps + 1)
    zainfekowani[0] = zainfekowani_initially
    alpha = beta * N - gamma
    
    for n in range(steps):
        zainfekowani_new = zainfekowani[n]
        
        for _ in range(max_iteracje):
            F = zainfekowani_new - zainfekowani[n] - (time_step / 2) * (
                (alpha * zainfekowani[n] - beta * zainfekowani[n]**2) + 
                (alpha * zainfekowani_new - beta * zainfekowani_new**2)
            )
            dF = 1 - (time_step / 2) * (alpha - 2 * beta * zainfekowani_new)
            
            delta = F / dF
            zainfekowani_nastepni = zainfekowani_new - delta
            
            if math.fabs(delta) < tolerancja:
                print(_)
                break
                
            zainfekowani_new = zainfekowani_nastepni

            
        zainfekowani[n + 1] = zainfekowani_new
        
    return czas, zainfekowani

def met_rk2(zainfekowani_initially, beta=0.001, gamma=0.1, N=500, time_step=0.1, czas_max=100, tolerancja=1e-6, max_iteracje=20):
    """Rozwiązanie metodą implicytną RK2."""
    # tabela Butchera
    c1 = 1/2 - np.sqrt(3)/6
    c2 = 1/2 + np.sqrt(3)/6
    a11 = 1/4
    a12 = 1/4 - np.sqrt(3)/6
    a21 = 1/4 + np.sqrt(3)/6
    a22 = 1/4
    b1 = 1/2
    b2 = 1/2
    
    steps = int(czas_max / time_step)
    czas = np.linspace(0, czas_max, steps + 1)
    zainfekowani = np.zeros(steps + 1)
    zainfekowani[0] = zainfekowani_initially
    alpha = beta * N - gamma
    
    for n in range(steps):
        U1 = zainfekowani[n]
        U2 = zainfekowani[n]
        
        for _ in range(max_iteracje):
            # F1 i F2
            F1 = U1 - zainfekowani[n] - time_step * (
                a11 * (alpha * U1 - beta * U1**2) + 
                a12 * (alpha * U2 - beta * U2**2)
            )
            F2 = U2 - zainfekowani[n] - time_step * (
                a21 * (alpha * U1 - beta * U1**2) + 
                a22 * (alpha * U2 - beta * U2**2)
            )
            
            #elementy Jacobiego
            m11 = 1 - time_step * a11 * (alpha - 2 * beta * U1)
            m12 = -time_step * a12 * (alpha - 2 * beta * U2)
            m21 = -time_step * a21 * (alpha - 2 * beta * U1)
            m22 = 1 - time_step * a22 * (alpha - 2 * beta * U2)
            
            # Rozwiąż dla poprawek
            det = m11 * m22 - m12 * m21
            dU1 = (F2 * m12 - F1 * m22) / det
            dU2 = (F1 * m21 - F2 * m11) / det
            
            U1_nastepni = U1 + dU1
            U2_nastepni = U2 + dU2
            
            if max(math.fabs(dU1), math.fabs(dU2)) < tolerancja:
                print(_)
                break
                
                
            U1 = U1_nastepni
            U2 = U2_nastepni
            
        # Krok poprawkowy
        zainfekowani[n + 1] = zainfekowani[n] + time_step * (
            b1 * (alpha * U1 - beta * U1**2) + 
            b1 * (alpha * U2 - beta * U2**2)
        )
        
    return czas, zainfekowani

# Parametry
zainfekowani_initially = 1
N = 500 

# Rozwiązanie wszystkimi metodami
czas_p, zainfekowani_p = met_picarda(zainfekowani_initially)
czas_n, zainfekowani_n = met_newtona(zainfekowani_initially)
czas_r, zainfekowani_r = met_rk2(zainfekowani_initially)

# Tworzenie wykresów
fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(10, 12))

# Wykres dla Trapezoidalnej metody Picarda
ax1.plot(czas_p, zainfekowani_p, 'b-', label='Zainfekowani (u)')
ax1.plot(czas_p, N - zainfekowani_p, 'r-', label='Wrażliwi (z)')
ax1.set_title('Metoda trapezoidalna z iteracją Picarda')
ax1.set_xlabel('Czas')
ax1.set_ylabel('Populacja')
ax1.legend()
ax1.grid(True)

# Wykres dla Trapezoidalnej metody Newtona
ax2.plot(czas_n, zainfekowani_n, 'b-', label='Zainfekowani (u)')
ax2.plot(czas_n, N - zainfekowani_n, 'r-', label='Wrażliwi (z)')
ax2.set_title('Metoda trapezoidalna z iteracją Newtona')
ax2.set_xlabel('Czas')
ax2.set_ylabel('Populacja')
ax2.legend()
ax2.grid(True)

# Wykres dla Implicytnej metody RK2
ax3.plot(czas_r, zainfekowani_r, 'b-', label='Zainfekowani (u)')
ax3.plot(czas_r, N - zainfekowani_r, 'r-', label='Wrażliwi (z)')
ax3.set_title('Metoda implicytna RK2')
ax3.set_xlabel('Czas')
ax3.set_ylabel('Populacja')
ax3.legend()
ax3.grid(True)

# Dopasowanie układu i zapis
plt.tight_layout()
plt.savefig('solution.png', dpi=300, bbox_inches='tight')
plt.close()
